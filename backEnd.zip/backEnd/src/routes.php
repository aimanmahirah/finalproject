<?php

//hello route
require __DIR__ . '/Controllers/hello.php';

//jobs route
require __DIR__ . '/Controllers/job.php';

