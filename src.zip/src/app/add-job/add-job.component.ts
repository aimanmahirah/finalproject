import { formatNumber } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { JobscompsService } from '../jobscomps.service';

@Component({
  selector: 'app-add-job',
  templateUrl: './add-job.component.html',
  styleUrls: ['./add-job.component.css']
})
export class AddJobComponent implements OnInit {

  constructor(private service: JobscompsService) { }

  addJob = new FormGroup({
    job_title: new FormControl(''),
    jstaff_name: new FormControl(''),
    jcomp_name: new FormControl(''),
    jstaff_email: new FormControl(''),
    jphone_num: new FormControl(''),
    comp_ssm: new FormControl('')

  });

  message: boolean = false;
  ngOnInit(): void {
  }

  createJob() {
    console.log(this.addJob.value);
    this.service.saveJobData(this.addJob.value).subscribe((result) => {
      console.log(result);
      this.message = true;
      this.addJob.reset({});
    });
  }

  removeMessage() {
    this.message = false;
  }
}
