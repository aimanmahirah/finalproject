import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';
import { JobscompsService } from '../jobscomps.service';
@Component({
  selector: 'app-edit-job',
  templateUrl: './edit-job.component.html',
  styleUrls: ['./edit-job.component.css']
})
export class EditJobComponent implements OnInit {
  
  
  

  constructor(private service: JobscompsService, private router: ActivatedRoute) { }

  editJob = new FormGroup({
    //id: new FormControl(''),
    job_title: new FormControl(''),
    jstaff_name: new FormControl(''),
    jcomp_name: new FormControl(''),
    jstaff_email: new FormControl(''),
    jphone_num: new FormControl(''),
    comp_ssm: new FormControl('')

  });
  message: boolean = false;
 
  ngOnInit(): void {
    
    this.service.getJobsById(this.router.snapshot.params['id']).subscribe((result:any) => {
      console.log(result);
      this.editJob = new FormGroup({
        //id: new FormControl(result['id']),
        job_title: new FormControl(result['job_title']),
        jstaff_name: new FormControl(result['jstaff_name']),
        jcomp_name: new FormControl(result['jcomp_name']),
        jstaff_email: new FormControl(result['jstaff_email']),
        jphone_num: new FormControl(result['jphone_num']),
        comp_ssm: new FormControl(result['comp_ssm']),
      });
    });
  }

  updateJob() {
    console.log(this.editJob.value);
    this.service.updateJobData(this.router.snapshot.params['id'], this.editJob.value).subscribe((result:any) => {
    this.message = true;
      
    });
  }

  removeMessage() {
    this.message = false;
  }


}

