import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  public registerForm !: FormGroup;
  constructor(private formBuilder: FormBuilder, private http: HttpClient, private router:Router) { }

  ngOnInit(): void {
    this.registerForm = this.formBuilder.group({
      staff_name:[''],
      staff_email:[''],
      staff_password:[''],
      staff_phonenum:[''],
      comp_name:[''],
      comp_ssm:[''],
      comp_size:[''],
      comp_type:['']
    })
  }

  reg(){
    this.http.post<any>("http://localhost:8888/register", this.registerForm.value).subscribe(result =>{
     alert("Success");
     this.registerForm.reset();
     this.router.navigate(['login']);
    })
  }

}
